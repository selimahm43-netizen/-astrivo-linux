import gi, os
try:
    gi.require_version('Gtk','3.0')
    from gi.repository import Gtk
except Exception:
    raise SystemExit
DONE=os.path.expanduser('~/.config/astrivo-setup-done')
class Setup(Gtk.Window):
    def __init__(self):
        super().__init__(title='Welcome to Astrivo Linux')
        self.set_default_size(700,460); self.set_border_width(24); self.set_resizable(False)
        self.stack=Gtk.Stack(); self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.lang=Gtk.ComboBoxText(); [self.lang.append_text(x) for x in ['English','العربية','Français','Español','Deutsch']]; self.lang.set_active(0)
        self.key=Gtk.ComboBoxText(); [self.key.append_text(x) for x in ['US English','UK English','Arabic','French','German']]; self.key.set_active(0)
        self.tz=Gtk.ComboBoxText(); [self.tz.append_text(x) for x in ['Automatic','Cairo','London','New York','Paris','Dubai']]; self.tz.set_active(0)
        self.theme=Gtk.ComboBoxText(); [self.theme.append_text(x) for x in ['Astrivo Dark','Astrivo Light','Follow system']]; self.theme.set_active(0)
        self.startup=Gtk.CheckButton(label='Show Astrivo welcome screen at startup'); self.startup.set_active(True)
        self.pages=[]
        self.add_page('Welcome to Astrivo Linux','Let’s personalize your computer in a few quick steps.')
        self.add_page('Language','Choose your preferred language.',self.lang)
        self.add_page('Keyboard','Choose your keyboard layout.',self.key)
        self.add_page('Time zone','Choose your time zone.',self.tz)
        self.add_page('Appearance','Choose the Astrivo desktop appearance.',self.theme)
        self.add_page('Ready','Your choices can be changed later in Settings.',self.startup)
        outer=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=18); outer.pack_start(self.stack,True,True,0)
        controls=Gtk.Box(spacing=10); self.back=Gtk.Button(label='Back'); self.next=Gtk.Button(label='Continue')
        self.back.connect('clicked',self.prev); self.next.connect('clicked',self.next_page); controls.pack_end(self.next,False,False,0); controls.pack_end(self.back,False,False,0)
        outer.pack_end(controls,False,False,0); self.add(outer); self.i=0; self.show_page()
    def add_page(self,title,body,widget=None):
        b=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=18); t=Gtk.Label(); t.set_markup('<big><b>'+title+'</b></big>'); t.set_xalign(0); b.pack_start(t,False,False,0); x=Gtk.Label(label=body); x.set_xalign(0); x.set_line_wrap(True); b.pack_start(x,False,False,0)
        if widget: b.pack_start(widget,False,False,0)
        self.stack.add_titled(b,title,title); self.pages.append(title)
    def show_page(self):
        self.stack.set_visible_child_name(self.pages[self.i]); self.back.set_sensitive(self.i>0); self.next.set_label('Finish' if self.i==len(self.pages)-1 else 'Continue')
    def prev(self,_): self.i-=1; self.show_page()
    def next_page(self,_):
        if self.i<len(self.pages)-1: self.i+=1; self.show_page()
        else:
            os.makedirs(os.path.dirname(DONE),exist_ok=True); open(DONE,'w').close(); self.destroy()
w=Setup(); w.connect('destroy',Gtk.main_quit); w.show_all(); Gtk.main()
