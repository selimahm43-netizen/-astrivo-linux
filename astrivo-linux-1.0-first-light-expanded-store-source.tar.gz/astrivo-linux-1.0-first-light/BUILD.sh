#!/bin/bash
set -e
[ "$EUID" -eq 0 ] || { echo 'Run: sudo ./BUILD.sh'; exit 1; }
lb clean --purge || true
lb config --distribution trixie --architectures amd64 --binary-images iso-hybrid \
  --image-name astrivo-linux-1.0-first-light \
  --archive-areas 'main contrib non-free-firmware' \
  --iso-application 'Astrivo Linux 1.0 - First Light' \
  --iso-publisher 'Astrivo Linux Project'
lb build
