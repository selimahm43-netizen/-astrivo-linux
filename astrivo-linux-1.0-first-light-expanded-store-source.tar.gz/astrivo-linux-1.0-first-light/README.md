# Astrivo Linux 1.0 — First Light

Debian Live amd64 prototype with XFCE, Astrivo branding, first-run personalization,
Firefox ESR, Steam support, Vulkan/Mesa, and VMware/VirtualBox guest packages.

## Build
Run on a supported Debian/Ubuntu-based Linux system:

    sudo apt update
    sudo apt install -y live-build debootstrap squashfs-tools xorriso grub-pc-bin grub-efi-amd64-bin mtools dosfstools
    sudo ./BUILD.sh

Expected output: `astrivo-linux-1.0-first-light-amd64.hybrid.iso`

This archive is the build source, not the ISO itself.

## Astrivo Store now contains a large install-on-demand catalog of 98 applications across Office, Multimedia, Graphics, Internet, Development, System, Utilities, Games, and Education. Apps are installed from Debian repositories when the user presses Install.

Astrivo Store now contains a large install-on-demand catalog of 98 applications across Office, Multimedia, Graphics, Internet, Development, System, Utilities, Games, and Education. Apps are installed from Debian repositories when the user presses Install.

The store is a lightweight APT front end rather than a separate proprietary repository.
An internet connection is required to install apps, and the system may ask for administrator authentication.

## Startup branding

The source includes an Astrivo Linux Plymouth startup theme and Astrivo logo asset.

## Important

This is a prototype build source. Test the resulting ISO in a virtual machine before
installing it on physical hardware. The first-run UI is a prototype and some choices
may require further integration with the underlying Debian/XFCE configuration.


## Expanded app catalog
The Store catalog contains 100+ app entries and is intentionally install-on-demand so the ISO does not become unnecessarily large.
